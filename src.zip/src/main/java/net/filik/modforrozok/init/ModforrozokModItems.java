/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.filik.modforrozok.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.filik.modforrozok.item.VegetaItem;
import net.filik.modforrozok.item.RozokItem;
import net.filik.modforrozok.ModforrozokMod;

import java.util.function.Function;

public class ModforrozokModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(ModforrozokMod.MODID);
	public static final DeferredItem<Item> BRAMBORA;
	public static final DeferredItem<Item> VEGETA;
	public static final DeferredItem<Item> BRAMBORABLOCK_3000;
	static {
		BRAMBORA = register("brambora", RozokItem::new);
		VEGETA = register("vegeta", VegetaItem::new);
		BRAMBORABLOCK_3000 = block(ModforrozokModBlocks.BRAMBORABLOCK_3000, new Item.Properties().stacksTo(99).rarity(Rarity.RARE));
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}