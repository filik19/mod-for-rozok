/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.filik.modforrozok.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.filik.modforrozok.block.Bramborablock3000Block;
import net.filik.modforrozok.ModforrozokMod;

import java.util.function.Function;

public class ModforrozokModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(ModforrozokMod.MODID);
	public static final DeferredBlock<Block> BRAMBORABLOCK_3000;
	static {
		BRAMBORABLOCK_3000 = register("bramborablock_3000", Bramborablock3000Block::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}