/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.filik.modforrozok.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.filik.modforrozok.ModforrozokMod;

@EventBusSubscriber
public class ModforrozokModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ModforrozokMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> CRATIVETABULATOR = REGISTRY.register("crativetabulator",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.modforrozok.crativetabulator")).icon(() -> new ItemStack(ModforrozokModItems.BRAMBORA.get())).displayItems((parameters, tabData) -> {
				tabData.accept(ModforrozokModItems.BRAMBORA.get());
				tabData.accept(ModforrozokModItems.VEGETA.get());
				tabData.accept(ModforrozokModBlocks.BRAMBORABLOCK_3000.get().asItem());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(ModforrozokModItems.BRAMBORA.get());
			tabData.accept(ModforrozokModItems.VEGETA.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(ModforrozokModBlocks.BRAMBORABLOCK_3000.get().asItem());
		}
	}
}