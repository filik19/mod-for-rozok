package net.filik.modforrozok.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class RozokItem extends Item {
	public RozokItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC).fireResistant().food((new FoodProperties.Builder()).nutrition(9).saturationModifier(9f).build()));
	}

	@Override
	public ItemStack getCraftingRemainder(ItemStack itemstack) {
		return new ItemStack(this);
	}

	@Override
	public boolean isCorrectToolForDrops(ItemStack itemstack, BlockState state) {
		return true;
	}
}