package net.filik.modforrozok.item;

import net.minecraft.world.item.component.Consumables;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class VegetaItem extends Item {
	public VegetaItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON).food((new FoodProperties.Builder()).nutrition(255).saturationModifier(99f).build(), Consumables.DEFAULT_DRINK));
	}
}